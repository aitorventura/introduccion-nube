#!/bin/bash
# Datos de usuario para la instancia base de la Actividad 4.1.
# Solo instala lo necesario para capturar la AMI propia de Escaparate -
# no arranca ninguna aplicacion, eso lo hace el script de la plantilla
# de lanzamiento (arranque-instancia.sh) en cada arranque real.

set -e

dnf install -y java-21-amazon-corretto postgresql15 amazon-efs-utils
